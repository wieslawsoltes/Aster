/* Build-only replacements for disabled Wine debug tracing. */
#ifndef ASTER_WINE_DEBUG_SHIM
#define ASTER_WINE_DEBUG_SHIM
#define WINE_DEFAULT_DEBUG_CHANNEL(name)
#define WINE_TRACE(...) ((void)0)
#define WINE_WARN(...) ((void)0)
#define WINE_ERR(...) ((void)0)
#define WINE_FIXME(...) ((void)0)
#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#endif
#endif
