/* Aster fixture build entry. App main.c/dialog.c are unchanged. */
#include <windows.h>
int WINAPI wWinMain(HINSTANCE, HINSTANCE, LPWSTR, int);
void aster_entry(void) {
    int result = wWinMain(GetModuleHandleW(0), 0, (LPWSTR)L"", SW_SHOWNORMAL);
    ExitProcess(result);
}
